import { db } from "./db";
import { organizations } from "@shared/schema";
import { eq } from "drizzle-orm";

async function seed() {
  console.log("Seeding database...");

  // Check if demo org already exists
  const existingOrg = await db
    .select()
    .from(organizations)
    .where(eq(organizations.orgCode, "DEMO"));

  if (existingOrg.length === 0) {
    await db.insert(organizations).values({
      orgCode: "DEMO",
      name: "Demo Organization",
      primaryColor: "#0EA5E9",
      secondaryColor: "#10B981",
      customFields: [],
      checklistTemplates: [],
    });
    console.log("✓ Created demo organization (orgCode: DEMO)");
  } else {
    console.log("✓ Demo organization already exists");
  }

  console.log("Seeding complete!");
  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});
