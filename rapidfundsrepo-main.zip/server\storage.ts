// Referenced from javascript_auth_all_persistance and javascript_database blueprints
import {
  users,
  organizations,
  fundingRequests,
  queryMessages,
  orgChartNodes,
  inviteTokens,
  approvalChains,
  approvalHistory,
  type User,
  type InsertUser,
  type Organization,
  type InsertOrganization,
  type FundingRequest,
  type InsertFundingRequest,
  type QueryMessage,
  type InsertQueryMessage,
  type OrgChartNode,
  type InsertOrgChartNode,
  type InviteToken,
  type InsertInviteToken,
  type ApprovalChain,
  type InsertApprovalChain,
  type ApprovalHistory,
  type InsertApprovalHistory,
} from "@shared/schema";
import { db } from "./db";
import { pool } from "./db";
import { eq, and, sql } from "drizzle-orm";
import session from "express-session";
import connectPg from "connect-pg-simple";

const PostgresSessionStore = connectPg(session);

export interface IStorage {
  sessionStore: session.Store;

  // User methods
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  getUserByEmailAndOrgCode(email: string, orgCode: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
  getUsersByOrg(orgId: string): Promise<User[]>;
  getUsersByOrgAndRole(orgId: string, role: string): Promise<User[]>;

  // Organization methods
  getOrganization(id: string): Promise<Organization | undefined>;
  getOrganizationByCode(orgCode: string): Promise<Organization | undefined>;
  createOrganization(insertOrg: InsertOrganization): Promise<Organization>;
  updateOrganization(id: string, data: Partial<Organization>): Promise<Organization>;

  // Funding Request methods
  getFundingRequest(id: string): Promise<FundingRequest | undefined>;
  getFundingRequestsByOrg(orgId: string): Promise<FundingRequest[]>;
  getFundingRequestsByUser(userId: string): Promise<FundingRequest[]>;
  createFundingRequest(insertRequest: InsertFundingRequest): Promise<FundingRequest>;
  updateFundingRequest(id: string, data: Partial<FundingRequest>): Promise<FundingRequest>;

  // Query Message methods
  getMessagesByRequest(requestId: string): Promise<QueryMessage[]>;
  createQueryMessage(insertMessage: InsertQueryMessage): Promise<QueryMessage>;

  // Org Chart methods
  getOrgChartNodesByOrg(orgId: string): Promise<OrgChartNode[]>;
  createOrgChartNode(insertNode: InsertOrgChartNode): Promise<OrgChartNode>;
  deleteOrgChartNode(id: string): Promise<void>;

  // Invite Token methods
  getInviteTokensByOrg(orgId: string): Promise<InviteToken[]>;
  getInviteTokenByToken(token: string): Promise<InviteToken | undefined>;
  createInviteToken(insertToken: InsertInviteToken): Promise<InviteToken>;
  markInviteTokenAsUsed(id: string, usedBy: string): Promise<InviteToken>;
  deleteInviteToken(id: string): Promise<void>;

  // Approval Chain methods
  getApprovalChainsByOrg(orgId: string): Promise<ApprovalChain[]>;
  getApprovalChain(id: string): Promise<ApprovalChain | undefined>;
  getDefaultApprovalChain(orgId: string): Promise<ApprovalChain | undefined>;
  createApprovalChain(insertChain: InsertApprovalChain): Promise<ApprovalChain>;
  updateApprovalChain(id: string, data: Partial<ApprovalChain>): Promise<ApprovalChain>;
  deleteApprovalChain(id: string): Promise<void>;

  // Approval History methods
  getApprovalHistoryByRequest(requestId: string): Promise<ApprovalHistory[]>;
  createApprovalHistory(insertHistory: InsertApprovalHistory): Promise<ApprovalHistory>;
}

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({
      pool,
      createTableIfMissing: true,
    });
  }

  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async getUserByEmailAndOrgCode(
    email: string,
    orgCode: string
  ): Promise<User | undefined> {
    const [org] = await db
      .select()
      .from(organizations)
      .where(eq(organizations.orgCode, orgCode));

    if (!org) return undefined;

    const [user] = await db
      .select()
      .from(users)
      .where(and(eq(users.email, email), eq(users.orgId, org.id)));

    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values(insertUser).returning();
    return user;
  }

  async getUsersByOrg(orgId: string): Promise<User[]> {
    return await db.select().from(users).where(eq(users.orgId, orgId));
  }

  async getUsersByOrgAndRole(orgId: string, role: string): Promise<User[]> {
    return await db
      .select()
      .from(users)
      .where(and(eq(users.orgId, orgId), eq(users.role, role)));
  }

  async getOrganization(id: string): Promise<Organization | undefined> {
    const [org] = await db
      .select()
      .from(organizations)
      .where(eq(organizations.id, id));
    return org || undefined;
  }

  async getOrganizationByCode(orgCode: string): Promise<Organization | undefined> {
    const [org] = await db
      .select()
      .from(organizations)
      .where(eq(organizations.orgCode, orgCode));
    return org || undefined;
  }

  async createOrganization(insertOrg: InsertOrganization): Promise<Organization> {
    const [org] = await db.insert(organizations).values(insertOrg).returning();
    return org;
  }

  async updateOrganization(
    id: string,
    data: Partial<Organization>
  ): Promise<Organization> {
    const [org] = await db
      .update(organizations)
      .set({ ...data, id: undefined } as any)
      .where(eq(organizations.id, id))
      .returning();
    return org;
  }

  async getFundingRequest(id: string): Promise<FundingRequest | undefined> {
    const [request] = await db
      .select()
      .from(fundingRequests)
      .where(eq(fundingRequests.id, id));
    return request || undefined;
  }

  async getFundingRequestsByOrg(orgId: string): Promise<FundingRequest[]> {
    return await db
      .select()
      .from(fundingRequests)
      .where(eq(fundingRequests.orgId, orgId))
      .orderBy(sql`${fundingRequests.createdAt} DESC`);
  }

  async getFundingRequestsByUser(userId: string): Promise<FundingRequest[]> {
    return await db
      .select()
      .from(fundingRequests)
      .where(eq(fundingRequests.requesterId, userId))
      .orderBy(sql`${fundingRequests.createdAt} DESC`);
  }

  async createFundingRequest(
    insertRequest: InsertFundingRequest
  ): Promise<FundingRequest> {
    const [request] = await db
      .insert(fundingRequests)
      .values(insertRequest)
      .returning();
    return request;
  }

  async updateFundingRequest(
    id: string,
    data: Partial<FundingRequest>
  ): Promise<FundingRequest> {
    const [request] = await db
      .update(fundingRequests)
      .set({ ...data, id: undefined, updatedAt: sql`NOW()` } as any)
      .where(eq(fundingRequests.id, id))
      .returning();
    return request;
  }

  async getMessagesByRequest(requestId: string): Promise<QueryMessage[]> {
    return await db
      .select()
      .from(queryMessages)
      .where(eq(queryMessages.requestId, requestId))
      .orderBy(sql`${queryMessages.createdAt} ASC`);
  }

  async createQueryMessage(
    insertMessage: InsertQueryMessage
  ): Promise<QueryMessage> {
    const [message] = await db
      .insert(queryMessages)
      .values(insertMessage)
      .returning();
    return message;
  }

  async getOrgChartNodesByOrg(orgId: string): Promise<OrgChartNode[]> {
    return await db
      .select()
      .from(orgChartNodes)
      .where(eq(orgChartNodes.orgId, orgId));
  }

  async createOrgChartNode(insertNode: InsertOrgChartNode): Promise<OrgChartNode> {
    const [node] = await db.insert(orgChartNodes).values(insertNode).returning();
    return node;
  }

  async deleteOrgChartNode(id: string): Promise<void> {
    await db.delete(orgChartNodes).where(eq(orgChartNodes.id, id));
  }

  async getInviteTokensByOrg(orgId: string): Promise<InviteToken[]> {
    return await db
      .select()
      .from(inviteTokens)
      .where(eq(inviteTokens.orgId, orgId))
      .orderBy(sql`${inviteTokens.createdAt} DESC`);
  }

  async getInviteTokenByToken(token: string): Promise<InviteToken | undefined> {
    const [inviteToken] = await db
      .select()
      .from(inviteTokens)
      .where(eq(inviteTokens.token, token));
    return inviteToken || undefined;
  }

  async createInviteToken(insertToken: InsertInviteToken): Promise<InviteToken> {
    const [token] = await db.insert(inviteTokens).values(insertToken).returning();
    return token;
  }

  async markInviteTokenAsUsed(id: string, usedBy: string): Promise<InviteToken> {
    const [token] = await db
      .update(inviteTokens)
      .set({ usedAt: sql`NOW()`, usedBy })
      .where(eq(inviteTokens.id, id))
      .returning();
    return token;
  }

  async deleteInviteToken(id: string): Promise<void> {
    await db.delete(inviteTokens).where(eq(inviteTokens.id, id));
  }

  async getApprovalChainsByOrg(orgId: string): Promise<ApprovalChain[]> {
    return await db
      .select()
      .from(approvalChains)
      .where(eq(approvalChains.orgId, orgId))
      .orderBy(sql`${approvalChains.createdAt} DESC`);
  }

  async getApprovalChain(id: string): Promise<ApprovalChain | undefined> {
    const [chain] = await db
      .select()
      .from(approvalChains)
      .where(eq(approvalChains.id, id));
    return chain || undefined;
  }

  async getDefaultApprovalChain(orgId: string): Promise<ApprovalChain | undefined> {
    const [chain] = await db
      .select()
      .from(approvalChains)
      .where(and(eq(approvalChains.orgId, orgId), eq(approvalChains.isDefault, true)));
    return chain || undefined;
  }

  async createApprovalChain(insertChain: InsertApprovalChain): Promise<ApprovalChain> {
    const [chain] = await db.insert(approvalChains).values(insertChain).returning();
    return chain;
  }

  async updateApprovalChain(
    id: string,
    data: Partial<ApprovalChain>
  ): Promise<ApprovalChain> {
    const [chain] = await db
      .update(approvalChains)
      .set({ ...data, id: undefined, updatedAt: sql`NOW()` } as any)
      .where(eq(approvalChains.id, id))
      .returning();
    return chain;
  }

  async deleteApprovalChain(id: string): Promise<void> {
    await db.delete(approvalChains).where(eq(approvalChains.id, id));
  }

  async getApprovalHistoryByRequest(requestId: string): Promise<ApprovalHistory[]> {
    return await db
      .select()
      .from(approvalHistory)
      .where(eq(approvalHistory.requestId, requestId))
      .orderBy(sql`${approvalHistory.createdAt} ASC`);
  }

  async createApprovalHistory(
    insertHistory: InsertApprovalHistory
  ): Promise<ApprovalHistory> {
    const [history] = await db
      .insert(approvalHistory)
      .values(insertHistory)
      .returning();
    return history;
  }
}

export const storage = new DatabaseStorage();
