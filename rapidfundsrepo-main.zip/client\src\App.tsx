import { Switch, Route, useLocation } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AuthProvider } from "@/hooks/use-auth";
import { ProtectedRoute } from "@/lib/protected-route";
import { SidebarProvider, SidebarTrigger } from "@/components/ui/sidebar";
import { AppSidebar } from "@/components/app-sidebar";
import { BottomNav } from "@/components/bottom-nav";
import NotFound from "@/pages/not-found";
import SplashPage from "@/pages/splash-page";
import AuthPage from "@/pages/auth-page";
import LoginPage from "@/pages/login-page";
import JoinOrgPage from "@/pages/join-org-page";
import CreateOrgPage from "@/pages/create-org-page";
import InviteRedirectPage from "@/pages/invite-redirect-page";
import DashboardPage from "@/pages/dashboard-page";
import CreateRequestPage from "@/pages/create-request-page";
import ApprovalsPage from "@/pages/approvals-page";
import OrgChartPage from "@/pages/org-chart-page";
import AdminSettingsPage from "@/pages/admin-settings-page";

function Router() {
  return (
    <Switch>
      {/* Splash screen - first page users see */}
      <Route path="/" component={SplashPage} />
      
      {/* Onboarding routes */}
      <Route path="/auth" component={AuthPage} />
      <Route path="/login" component={LoginPage} />
      <Route path="/join" component={JoinOrgPage} />
      <Route path="/invite/:token" component={InviteRedirectPage} />
      <Route path="/create-org" component={CreateOrgPage} />
      
      {/* Protected routes */}
      <ProtectedRoute path="/dashboard" component={DashboardPage} />
      <ProtectedRoute path="/create-request" component={CreateRequestPage} />
      <ProtectedRoute path="/approvals" component={ApprovalsPage} />
      <ProtectedRoute path="/org-chart" component={OrgChartPage} />
      <ProtectedRoute path="/admin-settings" component={AdminSettingsPage} />
      <ProtectedRoute path="/admin" component={AdminSettingsPage} />
      
      <Route component={NotFound} />
    </Switch>
  );
}

function AppLayout() {
  const [location] = useLocation();
  
  const isPublicRoute = 
    ['/', '/auth', '/login', '/join', '/create-org'].includes(location) || 
    location.startsWith('/invite/');

  return (
    <div className="flex h-screen w-full">
      {/* Conditionally render sidebar based on route */}
      {!isPublicRoute && <AppSidebar />}
      
      <main className="flex-1 overflow-hidden flex flex-col">
        {/* Header with sidebar toggle - only on protected routes */}
        {!isPublicRoute && (
          <header className="flex items-center gap-2 border-b px-4 py-2 bg-background">
            <SidebarTrigger data-testid="button-sidebar-toggle" />
            <div className="flex-1" />
          </header>
        )}
        
        {/* On public routes, allow scrolling. On protected routes, use overflow-hidden for proper layout */}
        <div className={isPublicRoute ? "flex-1 overflow-y-auto" : "flex-1 overflow-hidden"}>
          <Router />
        </div>
        
        {/* Bottom navigation - only on protected routes */}
        {!isPublicRoute && <BottomNav />}
      </main>
    </div>
  );
}

function App() {
  const style = {
    "--sidebar-width": "16rem",
    "--sidebar-width-icon": "3rem",
  };

  return (
    <QueryClientProvider client={queryClient}>
      <AuthProvider>
        <TooltipProvider>
          <SidebarProvider style={style as React.CSSProperties}>
            <AppLayout />
          </SidebarProvider>
          <Toaster />
        </TooltipProvider>
      </AuthProvider>
    </QueryClientProvider>
  );
}

export default App;
