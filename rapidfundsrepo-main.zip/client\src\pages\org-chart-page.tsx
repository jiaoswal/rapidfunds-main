import { useQuery, useMutation } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { OrgChartNode } from "@shared/schema";
import { Plus, Users, Trash2, UserPlus, ZoomIn, ZoomOut, Maximize2, Edit } from "lucide-react";
import { useState } from "react";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Tree, TreeNode } from "react-organizational-chart";
import { 
  DndContext, 
  DragEndEvent,
  DragOverlay,
  useSensor,
  useSensors,
  PointerSensor,
  closestCenter
} from '@dnd-kit/core';
import { CSS } from '@dnd-kit/utilities';
import { useDraggable, useDroppable } from '@dnd-kit/core';

// Draggable Employee Card Component
function DraggableCard({ 
  node, 
  onDelete, 
  onAddChild, 
  onEdit,
  isAdmin,
  isDragging
}: { 
  node: OrgChartNode; 
  onDelete: (id: string) => void; 
  onAddChild: (parentId: string) => void;
  onEdit: (node: OrgChartNode) => void;
  isAdmin: boolean;
  isDragging?: boolean;
}) {
  const { attributes, listeners, setNodeRef, transform, isDragging: isDraggingActive } = useDraggable({
    id: node.id,
    data: node,
  });

  const { setNodeRef: setDropRef, isOver } = useDroppable({
    id: node.id,
    data: node,
  });

  const style = transform ? {
    transform: CSS.Translate.toString(transform),
  } : undefined;

  return (
    <div 
      ref={setDropRef}
      style={style}
      className={`relative ${isOver ? 'ring-2 ring-primary' : ''}`}
    >
      <Card 
        ref={isAdmin ? setNodeRef : undefined}
        className={`
          w-64 transition-all duration-200 
          ${isDraggingActive ? 'opacity-50 cursor-grabbing' : 'cursor-grab'}
          ${isOver ? 'scale-105 shadow-lg' : 'hover-elevate'}
        `}
        style={{ borderTop: `4px solid ${node.color || "#0EA5E9"}` }}
        data-testid={`node-${node.id}`}
        {...(isAdmin ? listeners : {})}
        {...(isAdmin ? attributes : {})}
      >
        <CardContent className="p-4">
          <div className="flex items-start gap-3">
            {/* Avatar */}
            <div
              className="h-12 w-12 rounded-full flex items-center justify-center text-white font-semibold flex-shrink-0"
              style={{ backgroundColor: node.color || "#0EA5E9" }}
            >
              {node.name.split(" ").map((n) => n[0]).join("").toUpperCase().slice(0, 2)}
            </div>
            
            {/* Info */}
            <div className="flex-1 min-w-0">
              <h4 className="font-semibold text-foreground truncate" data-testid={`text-node-name-${node.id}`}>
                {node.name}
              </h4>
              <p className="text-sm text-muted-foreground truncate">{node.role}</p>
              {node.department && (
                <p className="text-xs text-muted-foreground mt-1 truncate">{node.department}</p>
              )}
            </div>
          </div>

          {/* Actions */}
          {isAdmin && (
            <div className="flex gap-2 mt-3 pt-3 border-t border-border">
              <Button
                variant="outline"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onAddChild(node.id);
                }}
                className="flex-1"
                data-testid={`button-add-child-${node.id}`}
              >
                <UserPlus className="h-3 w-3 mr-1" />
                Add Report
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onEdit(node);
                }}
                data-testid={`button-edit-node-${node.id}`}
              >
                <Edit className="h-3 w-3" />
              </Button>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  onDelete(node.id);
                }}
                data-testid={`button-delete-node-${node.id}`}
              >
                <Trash2 className="h-3 w-3" />
              </Button>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}

// Recursive Tree Builder
function OrgTreeNode({ 
  node, 
  allNodes, 
  onDelete, 
  onAddChild,
  onEdit, 
  isAdmin 
}: { 
  node: OrgChartNode; 
  allNodes: OrgChartNode[];
  onDelete: (id: string) => void; 
  onAddChild: (parentId: string) => void;
  onEdit: (node: OrgChartNode) => void;
  isAdmin: boolean;
}) {
  const children = allNodes.filter(n => n.parentId === node.id);

  return (
    <TreeNode
      label={
        <DraggableCard
          node={node}
          onDelete={onDelete}
          onAddChild={onAddChild}
          onEdit={onEdit}
          isAdmin={isAdmin}
        />
      }
    >
      {children.map(child => (
        <OrgTreeNode
          key={child.id}
          node={child}
          allNodes={allNodes}
          onDelete={onDelete}
          onAddChild={onAddChild}
          onEdit={onEdit}
          isAdmin={isAdmin}
        />
      ))}
    </TreeNode>
  );
}

export default function OrgChartPage() {
  const { user } = useAuth();
  const { toast } = useToast();
  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [selectedParentId, setSelectedParentId] = useState<string | null>(null);
  const [editingNode, setEditingNode] = useState<OrgChartNode | null>(null);
  const [zoom, setZoom] = useState(1);

  const [name, setName] = useState("");
  const [role, setRole] = useState("");
  const [department, setDepartment] = useState("");
  const [color, setColor] = useState("#0EA5E9");

  const sensors = useSensors(
    useSensor(PointerSensor, {
      activationConstraint: {
        distance: 8,
      },
    })
  );

  const { data: nodes, isLoading } = useQuery<OrgChartNode[]>({
    queryKey: ["/api/org-chart"],
  });

  const createNodeMutation = useMutation({
    mutationFn: async (data: any) => {
      const res = await apiRequest("POST", "/api/org-chart", data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/org-chart"] });
      toast({
        title: "Success",
        description: editingNode ? "Person updated successfully" : "Person added to org chart",
      });
      setIsAddDialogOpen(false);
      resetForm();
    },
  });

  const updateNodeMutation = useMutation({
    mutationFn: async ({ id, data }: { id: string; data: any }) => {
      const res = await apiRequest("PATCH", `/api/org-chart/${id}`, data);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/org-chart"] });
      toast({
        title: "Success",
        description: "Person updated successfully",
      });
      setIsAddDialogOpen(false);
      resetForm();
    },
  });

  const deleteNodeMutation = useMutation({
    mutationFn: async (id: string) => {
      const res = await apiRequest("DELETE", `/api/org-chart/${id}`);
      return await res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/org-chart"] });
      toast({
        title: "Node deleted",
        description: "The person has been removed from the org chart",
      });
    },
  });

  const resetForm = () => {
    setName("");
    setRole("");
    setDepartment("");
    setColor("#0EA5E9");
    setSelectedParentId(null);
    setEditingNode(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const data = {
      name,
      role,
      department: department || null,
      parentId: selectedParentId,
      color,
      shape: "rectangle",
      position: { x: 0, y: 0 },
    };

    if (editingNode) {
      updateNodeMutation.mutate({ id: editingNode.id, data });
    } else {
      createNodeMutation.mutate(data);
    }
  };

  const handleAddChild = (parentId: string) => {
    setSelectedParentId(parentId);
    setEditingNode(null);
    setIsAddDialogOpen(true);
  };

  const handleEdit = (node: OrgChartNode) => {
    setName(node.name);
    setRole(node.role);
    setDepartment(node.department || "");
    setColor(node.color || "#0EA5E9");
    setSelectedParentId(node.parentId);
    setEditingNode(node);
    setIsAddDialogOpen(true);
  };

  const handleDragEnd = (event: DragEndEvent) => {
    const { active, over } = event;
    
    if (!over || active.id === over.id) return;

    // Don't allow dropping on own children
    const draggedNode = nodes?.find(n => n.id === active.id);
    const targetNode = nodes?.find(n => n.id === over.id);

    if (!draggedNode || !targetNode) return;

    // Check if target is a child of dragged node
    const isChild = (parentId: string, childId: string): boolean => {
      const node = nodes?.find(n => n.id === childId);
      if (!node) return false;
      if (node.parentId === parentId) return true;
      if (node.parentId) return isChild(parentId, node.parentId);
      return false;
    };

    if (isChild(draggedNode.id, targetNode.id)) {
      toast({
        title: "Invalid move",
        description: "Cannot move a person under their own subordinate",
        variant: "destructive",
      });
      return;
    }

    // Update the parent
    updateNodeMutation.mutate({
      id: draggedNode.id,
      data: { ...draggedNode, parentId: targetNode.id },
    });
  };

  const isAdmin = user?.role === "Admin";
  const rootNodes = nodes?.filter(n => !n.parentId) || [];

  return (
    <DndContext
      sensors={sensors}
      collisionDetection={closestCenter}
      onDragEnd={handleDragEnd}
    >
      <div className="container mx-auto p-6 max-w-full">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-2" data-testid="text-page-title">
              <Users className="h-8 w-8" />
              Organization Chart
            </h1>
            <p className="text-muted-foreground mt-1">
              {isAdmin ? 'Drag and drop to reorganize • Click to add or edit' : 'Visual hierarchy of your organization'}
            </p>
          </div>

          <div className="flex items-center gap-2">
            {/* Zoom Controls */}
            <div className="flex items-center gap-1 mr-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setZoom(Math.max(0.5, zoom - 0.1))}
                data-testid="button-zoom-out"
              >
                <ZoomOut className="h-4 w-4" />
              </Button>
              <span className="text-sm text-muted-foreground w-12 text-center">
                {Math.round(zoom * 100)}%
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setZoom(Math.min(2, zoom + 0.1))}
                data-testid="button-zoom-in"
              >
                <ZoomIn className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setZoom(1)}
                data-testid="button-zoom-reset"
              >
                <Maximize2 className="h-4 w-4" />
              </Button>
            </div>

            {isAdmin && (
              <Dialog open={isAddDialogOpen} onOpenChange={(open) => {
                if (!open) resetForm();
                setIsAddDialogOpen(open);
              }}>
                <DialogTrigger asChild>
                  <Button 
                    onClick={() => {
                      resetForm();
                      setIsAddDialogOpen(true);
                    }}
                    data-testid="button-add-node"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Add {rootNodes.length === 0 ? 'Root Person' : 'Person'}
                  </Button>
                </DialogTrigger>
                <DialogContent>
                  <DialogHeader>
                    <DialogTitle>
                      {editingNode ? 'Edit Person' : 'Add Person to Organization'}
                    </DialogTitle>
                    <DialogDescription>
                      {editingNode 
                        ? 'Update the person details' 
                        : selectedParentId 
                        ? 'Add a direct report' 
                        : 'Add a root person (CEO/President)'}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div>
                      <Label htmlFor="name">Full Name *</Label>
                      <Input
                        id="name"
                        data-testid="input-name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="role">Job Title *</Label>
                      <Input
                        id="role"
                        data-testid="input-role"
                        value={role}
                        onChange={(e) => setRole(e.target.value)}
                        required
                      />
                    </div>
                    <div>
                      <Label htmlFor="department">Department</Label>
                      <Input
                        id="department"
                        data-testid="input-department"
                        value={department}
                        onChange={(e) => setDepartment(e.target.value)}
                      />
                    </div>
                    <div>
                      <Label htmlFor="color">Card Color</Label>
                      <div className="flex gap-2 mt-2">
                        {['#0EA5E9', '#10B981', '#F59E0B', '#EF4444', '#8B5CF6', '#EC4899'].map((c) => (
                          <button
                            key={c}
                            type="button"
                            className={`h-10 w-10 rounded-full border-2 ${color === c ? 'border-foreground' : 'border-border'}`}
                            style={{ backgroundColor: c }}
                            onClick={() => setColor(c)}
                            data-testid={`button-color-${c}`}
                          />
                        ))}
                      </div>
                    </div>
                    <div className="flex gap-2 pt-4">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => {
                          setIsAddDialogOpen(false);
                          resetForm();
                        }}
                        className="flex-1"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        disabled={createNodeMutation.isPending || updateNodeMutation.isPending}
                        className="flex-1"
                        data-testid="button-submit"
                      >
                        {editingNode ? 'Update' : 'Add'} Person
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            )}
          </div>
        </div>

        {/* Org Chart Tree */}
        {isLoading ? (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
          </div>
        ) : rootNodes.length === 0 ? (
          <div className="text-center py-12">
            <Users className="h-16 w-16 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Organization Chart Yet</h3>
            <p className="text-muted-foreground mb-4">
              {isAdmin 
                ? 'Start by adding a root person (CEO, President, or Director)' 
                : 'Contact an admin to set up the organization chart'}
            </p>
            {isAdmin && (
              <Button onClick={() => setIsAddDialogOpen(true)}>
                <Plus className="h-4 w-4 mr-2" />
                Add Root Person
              </Button>
            )}
          </div>
        ) : (
          <div className="overflow-auto pb-8 bg-muted/20 rounded-lg p-8">
            <div 
              style={{ 
                transform: `scale(${zoom})`,
                transformOrigin: 'top center',
                transition: 'transform 0.2s ease-in-out'
              }}
            >
              <Tree
                lineWidth="2px"
                lineColor="#CBD5E1"
                lineBorderRadius="10px"
                label={<div />}
              >
                {rootNodes.map((node) => (
                  <OrgTreeNode
                    key={node.id}
                    node={node}
                    allNodes={nodes || []}
                    onDelete={(id) => deleteNodeMutation.mutate(id)}
                    onAddChild={handleAddChild}
                    onEdit={handleEdit}
                    isAdmin={isAdmin}
                  />
                ))}
              </Tree>
            </div>
          </div>
        )}
      </div>
    </DndContext>
  );
}
