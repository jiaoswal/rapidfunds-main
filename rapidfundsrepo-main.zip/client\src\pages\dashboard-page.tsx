import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/use-auth";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { FileText, CheckCircle, XCircle, Clock, TrendingUp, DollarSign, Users, Network, Settings, LayoutDashboard, ClipboardList } from "lucide-react";
import { FundingRequest, Organization } from "@shared/schema";

export default function DashboardPage() {
  const { user } = useAuth();

  const { data: requests, isLoading: requestsLoading } = useQuery<FundingRequest[]>({
    queryKey: ["/api/requests"],
  });

  const { data: organization } = useQuery<Organization>({
    queryKey: ["/api/organization"],
  });

  const pendingCount = requests?.filter((r) => r.status === "Pending").length || 0;
  const approvedCount = requests?.filter((r) => r.status === "Approved").length || 0;
  const rejectedCount = requests?.filter((r) => r.status === "Rejected").length || 0;

  const totalAmount = requests?.reduce((sum, r) => sum + r.amount, 0) || 0;
  const approvedAmount = requests?.filter((r) => r.status === "Approved").reduce((sum, r) => sum + r.amount, 0) || 0;

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "Pending":
        return <Badge className="bg-pending text-pending-foreground" data-testid={`badge-status-pending`}>Pending</Badge>;
      case "Approved":
        return <Badge className="bg-success text-success-foreground" data-testid={`badge-status-approved`}>Approved</Badge>;
      case "Rejected":
        return <Badge variant="destructive" data-testid={`badge-status-rejected`}>Rejected</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const recentRequests = requests?.slice(0, 5) || [];

  return (
    <div className="flex-1 overflow-auto">
      <div className="p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-foreground" data-testid="text-page-title">Dashboard</h1>
            <p className="text-muted-foreground mt-1" data-testid="text-org-name">
              {organization?.name || "Loading..."}
            </p>
          </div>
          <Button asChild data-testid="button-new-request">
            <Link href="/create-request">
              <FileText className="h-4 w-4 mr-2" />
              New Request
            </Link>
          </Button>
        </div>

        {/* Stats Cards */}
        <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Requests</CardTitle>
              <FileText className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-requests">{requests?.length || 0}</div>
              <p className="text-xs text-muted-foreground">All time</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Pending</CardTitle>
              <Clock className="h-4 w-4 text-pending" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-pending" data-testid="text-pending-count">{pendingCount}</div>
              <p className="text-xs text-muted-foreground">Awaiting approval</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Approved</CardTitle>
              <CheckCircle className="h-4 w-4 text-success" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-success" data-testid="text-approved-count">{approvedCount}</div>
              <p className="text-xs text-muted-foreground">${approvedAmount.toLocaleString()} funded</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Amount</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold" data-testid="text-total-amount">${totalAmount.toLocaleString()}</div>
              <p className="text-xs text-muted-foreground">Requested</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Requests */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Requests</CardTitle>
            <CardDescription>Your latest funding requests</CardDescription>
          </CardHeader>
          <CardContent>
            {requestsLoading ? (
              <div className="flex items-center justify-center py-8">
                <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary"></div>
              </div>
            ) : recentRequests.length === 0 ? (
              <div className="text-center py-8">
                <FileText className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
                <p className="text-muted-foreground">No requests yet</p>
                <Button asChild className="mt-4" variant="outline" data-testid="button-create-first-request">
                  <Link href="/create-request">Create your first request</Link>
                </Button>
              </div>
            ) : (
              <div className="space-y-4">
                {recentRequests.map((request) => (
                  <div
                    key={request.id}
                    className="flex items-center justify-between p-4 border border-border rounded-lg hover-elevate"
                    data-testid={`card-request-${request.id}`}
                  >
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-1">
                        <h4 className="font-semibold text-foreground" data-testid={`text-request-title-${request.id}`}>{request.title}</h4>
                        {getStatusBadge(request.status)}
                      </div>
                      <p className="text-sm text-muted-foreground line-clamp-1">{request.description}</p>
                      <div className="flex items-center gap-4 mt-2">
                        <span className="text-sm text-muted-foreground">
                          <span className="font-medium text-foreground">${request.amount.toLocaleString()}</span>
                        </span>
                        <span className="text-sm text-muted-foreground">{request.category}</span>
                        <span className="text-sm text-muted-foreground">
                          {new Date(request.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
