import type { Express } from "express";
import { createServer, type Server } from "http";
import { setupAuth, hashPassword } from "./auth";
import { storage } from "./storage";
import multer from "multer";
import { writeFile, mkdir } from "fs/promises";
import path from "path";
import { nanoid } from "nanoid";
import { sql } from "drizzle-orm";

// Configure multer for file uploads (in memory)
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 10 * 1024 * 1024 }, // 10MB limit
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Sets up /api/register, /api/login, /api/logout, /api/user
  setupAuth(app);

  // File upload endpoint
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (!req.file) return res.status(400).send("No file uploaded");

    try {
      // Use local .private directory in project root
      const privateDirBase = path.resolve(process.cwd(), ".private");
      
      const fileId = nanoid();
      const ext = path.extname(req.file.originalname);
      const fileName = `${fileId}${ext}`;
      const filePath = path.join(privateDirBase, fileName);

      // Ensure directory exists (recursive creates all parent dirs)
      await mkdir(privateDirBase, { recursive: true });

      // Write file to storage
      await writeFile(filePath, req.file.buffer);

      res.json({
        name: req.file.originalname,
        url: `/api/files/${fileName}`,
        size: req.file.size,
        id: fileId,
      });
    } catch (error) {
      console.error("File upload error:", error);
      res.status(500).send(`File upload failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  });

  // File download endpoint
  app.get("/api/files/:fileId", async (req, res) => {
    if (!req.isAuthenticated()) return res.sendStatus(401);

    try {
      const fileId = req.params.fileId;
      
      // Security: Prevent path traversal by validating filename
      if (!fileId || fileId.includes("..") || fileId.includes("/") || fileId.includes("\\")) {
        return res.status(400).send("Invalid file ID");
      }

      const privateDirBase = path.resolve(process.cwd(), ".private");
      const filePath = path.join(privateDirBase, fileId);
      
      // Ensure the resolved path is still within the private directory
      if (!filePath.startsWith(privateDirBase)) {
        return res.status(403).send("Access denied");
      }

      res.sendFile(filePath);
    } catch (error) {
      res.status(404).send("File not found");
    }
  });

  // Logo upload endpoint (stored in public directory)
  app.post("/api/upload/logo", upload.single("file"), async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);
    if (!req.file) return res.status(400).send("No file uploaded");

    try {
      // Validate file type
      if (!req.file.mimetype.startsWith("image/")) {
        return res.status(400).send("Only image files are allowed");
      }

      // Use local .public directory in project root for logos
      const publicDirBase = path.resolve(process.cwd(), ".public");
      
      const fileId = nanoid();
      const ext = path.extname(req.file.originalname);
      const fileName = `logo-${fileId}${ext}`;
      const filePath = path.join(publicDirBase, fileName);

      // Ensure directory exists
      await mkdir(publicDirBase, { recursive: true });

      // Write file to storage
      await writeFile(filePath, req.file.buffer);

      res.json({
        logoUrl: `/api/public/${fileName}`,
      });
    } catch (error) {
      console.error("Logo upload error:", error);
      res.status(500).send(`Logo upload failed: ${error instanceof Error ? error.message : "Unknown error"}`);
    }
  });

  // Public file access (no auth required - for logos)
  app.get("/api/public/:fileName", async (req, res) => {
    try {
      const fileName = req.params.fileName;
      
      // Security: Prevent path traversal by validating filename
      if (!fileName || fileName.includes("..") || fileName.includes("/") || fileName.includes("\\")) {
        return res.status(400).send("Invalid file name");
      }

      const publicDirBase = path.resolve(process.cwd(), ".public");
      const filePath = path.join(publicDirBase, fileName);
      
      // Ensure the resolved path is still within the public directory
      if (!filePath.startsWith(publicDirBase)) {
        return res.status(403).send("Access denied");
      }

      res.sendFile(filePath);
    } catch (error) {
      res.status(404).send("File not found");
    }
  });

  // Create organization (for first-time setup / admin creation)
  app.post("/api/organizations/create", async (req, res) => {
    const { orgCode, name, adminEmail, adminPassword, adminFullName } = req.body;

    if (!orgCode || !name || !adminEmail || !adminPassword || !adminFullName) {
      return res.status(400).send("Missing required fields");
    }

    // Normalize email to lowercase for case-insensitive storage
    const normalizedEmail = adminEmail.toLowerCase().trim();

    // Check if org code already exists
    const existing = await storage.getOrganizationByCode(orgCode);
    if (existing) {
      return res.status(400).send("Organization code already exists");
    }

    // Check if admin email already exists
    const existingUser = await storage.getUserByEmail(normalizedEmail);
    if (existingUser) {
      return res.status(400).send("Email already in use");
    }

    try {
      // Create organization
      const org = await storage.createOrganization({
        orgCode,
        name,
        primaryColor: "#0EA5E9",
        secondaryColor: "#10B981",
        customFields: [],
        checklistTemplates: [],
      });

      // Create admin user for the organization
      const hashedPassword = await hashPassword(adminPassword);
      
      const adminUser = await storage.createUser({
        orgId: org.id,
        orgCode: org.orgCode,
        email: normalizedEmail,
        password: hashedPassword,
        fullName: adminFullName,
        role: "Admin",
        department: null,
        customFieldsData: {},
      });

      // Auto-login the admin user
      req.login(adminUser, (err) => {
        if (err) {
          console.error("Auto-login error:", err);
          return res.status(500).send("Organization created but login failed");
        }
        
        res.status(201).json({ 
          organization: org, 
          user: adminUser,
          message: "Organization created successfully! You are now logged in." 
        });
      });
    } catch (error) {
      console.error("Organization creation error:", error);
      res.status(500).send("Failed to create organization");
    }
  });

  // Organization routes
  app.get("/api/organization", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const org = await storage.getOrganization(req.user.orgId);
    if (!org) return res.sendStatus(404);

    res.json(org);
  });

  app.patch("/api/organization", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const org = await storage.updateOrganization(req.user.orgId, req.body);
    res.json(org);
  });

  // Users routes
  app.get("/api/users", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const users = await storage.getUsersByOrg(req.user.orgId);
    res.json(users);
  });

  app.get("/api/approvers", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const approvers = await storage.getUsersByOrgAndRole(req.user.orgId, "Approver");
    const admins = await storage.getUsersByOrgAndRole(req.user.orgId, "Admin");
    res.json([...approvers, ...admins]);
  });

  // Funding Request routes
  app.get("/api/requests", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const requests = await storage.getFundingRequestsByOrg(req.user.orgId);
    res.json(requests);
  });

  app.post("/api/requests", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const request = await storage.createFundingRequest({
      ...req.body,
      orgId: req.user.orgId,
      requesterId: req.user.id,
    });

    res.status(201).json(request);
  });

  app.patch("/api/requests/:id/status", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const request = await storage.getFundingRequest(req.params.id);
    if (!request) return res.sendStatus(404);
    if (request.orgId !== req.user.orgId) return res.sendStatus(403);

    // Only Approvers and Admins can change status
    if (req.user.role !== "Approver" && req.user.role !== "Admin") {
      return res.sendStatus(403);
    }

    const { status, comments, isFastTrack } = req.body;

    // Create approval history entry
    await storage.createApprovalHistory({
      requestId: req.params.id,
      level: request.currentApprovalLevel || 1,
      approverId: req.user.id,
      action: status,
      comments: comments || null,
      isFastTrack: isFastTrack || false,
    });

    // If approved and there's an approval chain, check if we need to forward to next level
    if (status === "Approved" && !isFastTrack && request.approvalChainId) {
      const chain = await storage.getApprovalChain(request.approvalChainId);
      
      if (chain) {
        const currentLevel = request.currentApprovalLevel || 1;
        const nextLevel = currentLevel + 1;
        const nextApprover = chain.levels.find(l => l.level === nextLevel);

        if (nextApprover) {
          // Forward to next level
          const updated = await storage.updateFundingRequest(req.params.id, {
            currentApprovalLevel: nextLevel,
            approverId: nextApprover.approverId,
            status: "Open", // Keep as Open for next approver
            lastActivityAt: sql`NOW()` as any,
          });
          
          return res.json({
            ...updated,
            message: `Request forwarded to Level ${nextLevel} approver: ${nextApprover.approverName}`,
          });
        } else {
          // Final approval - no more levels
          const updated = await storage.updateFundingRequest(req.params.id, {
            status: "Approved",
            lastActivityAt: sql`NOW()` as any,
          });
          
          return res.json({
            ...updated,
            message: "Request fully approved - all levels complete",
          });
        }
      }
    }

    // Simple status update (rejection, needs info, or fast-track approval)
    const updated = await storage.updateFundingRequest(req.params.id, {
      status,
      lastActivityAt: sql`NOW()` as any,
    });

    res.json(updated);
  });

  // Query Messages routes (formerly comments)
  app.get("/api/requests/:id/messages", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const messages = await storage.getMessagesByRequest(req.params.id);
    res.json(messages);
  });

  app.post("/api/requests/:id/messages", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const message = await storage.createQueryMessage({
      requestId: req.params.id,
      userId: req.user.id,
      messageType: req.body.messageType || "text",
      content: req.body.content,
      attachments: req.body.attachments || [],
    });

    res.status(201).json(message);
  });

  // Invite Token routes
  app.get("/api/invite-tokens", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const tokens = await storage.getInviteTokensByOrg(req.user.orgId);
    res.json(tokens);
  });

  app.post("/api/invite-tokens", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const { role, expiresInDays } = req.body;
    if (!role || !["Admin", "Approver", "Requester"].includes(role)) {
      return res.status(400).send("Invalid role");
    }

    // Generate secure random token
    const token = nanoid(32);
    
    // Calculate expiration date
    const expiresAt = new Date();
    expiresAt.setDate(expiresAt.getDate() + (expiresInDays || 7));

    const inviteToken = await storage.createInviteToken({
      orgId: req.user.orgId,
      token,
      role,
      createdBy: req.user.id,
      expiresAt,
    });

    res.status(201).json(inviteToken);
  });

  app.delete("/api/invite-tokens/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    await storage.deleteInviteToken(req.params.id);
    res.sendStatus(204);
  });

  // Public endpoint to validate invite token (no auth required)
  app.get("/api/invite-tokens/validate/:token", async (req, res) => {
    const { token } = req.params;
    
    if (!token) {
      return res.status(400).json({ valid: false, error: "Token is required" });
    }

    // Get the invite token
    const inviteToken = await storage.getInviteTokenByToken(token);

    if (!inviteToken) {
      return res.status(404).json({ valid: false, error: "Token not found" });
    }

    // Check if token is expired
    if (new Date(inviteToken.expiresAt) < new Date()) {
      return res.status(400).json({ valid: false, error: "Token has expired" });
    }

    // Check if token was already used
    if (inviteToken.usedAt) {
      return res.status(400).json({ valid: false, error: "Token has already been used" });
    }

    // Get organization details
    const org = await storage.getOrganization(inviteToken.orgId);
    if (!org) {
      return res.status(404).json({ valid: false, error: "Organization not found" });
    }

    // Return token details with org code
    res.json({
      valid: true,
      role: inviteToken.role,
      orgCode: org.orgCode,
      orgName: org.name,
      expiresAt: inviteToken.expiresAt,
    });
  });

  // Org Chart routes
  app.get("/api/org-chart", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const nodes = await storage.getOrgChartNodesByOrg(req.user.orgId);
    res.json(nodes);
  });

  app.post("/api/org-chart", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const node = await storage.createOrgChartNode({
      ...req.body,
      orgId: req.user.orgId,
    });

    res.status(201).json(node);
  });

  app.delete("/api/org-chart/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    await storage.deleteOrgChartNode(req.params.id);
    res.sendStatus(204);
  });

  // Approval Chain routes (Admin only)
  app.get("/api/approval-chains", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const chains = await storage.getApprovalChainsByOrg(req.user.orgId);
    res.json(chains);
  });

  app.get("/api/approval-chains/default", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const chain = await storage.getDefaultApprovalChain(req.user.orgId);
    res.json(chain || null);
  });

  app.post("/api/approval-chains", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const chain = await storage.createApprovalChain({
      ...req.body,
      orgId: req.user.orgId,
    });

    res.status(201).json(chain);
  });

  app.patch("/api/approval-chains/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    const chain = await storage.updateApprovalChain(req.params.id, req.body);
    res.json(chain);
  });

  app.delete("/api/approval-chains/:id", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);
    if (req.user.role !== "Admin") return res.sendStatus(403);

    await storage.deleteApprovalChain(req.params.id);
    res.sendStatus(204);
  });

  // Approval History routes
  app.get("/api/requests/:id/approval-history", async (req, res) => {
    if (!req.isAuthenticated() || !req.user) return res.sendStatus(401);

    const history = await storage.getApprovalHistoryByRequest(req.params.id);
    res.json(history);
  });

  const httpServer = createServer(app);

  return httpServer;
}
