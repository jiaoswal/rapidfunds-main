import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Organizations table
export const organizations = pgTable("organizations", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgCode: varchar("org_code", { length: 50 }).notNull().unique(),
  name: text("name").notNull(),
  domain: text("domain"),
  logoUrl: text("logo_url"),
  primaryColor: varchar("primary_color", { length: 7 }).default("#0EA5E9"),
  secondaryColor: varchar("secondary_color", { length: 7 }).default("#10B981"),
  customFields: jsonb("custom_fields").default([]).$type<{ name: string; type: string; required: boolean }[]>(),
  checklistTemplates: jsonb("checklist_templates").default([]).$type<{ id: string; name: string; category: string; department: string; items: { id: string; text: string; type: string; required: boolean }[] }[]>(),
  approvalRules: jsonb("approval_rules").default([]).$type<{ department: string; approvers: string[]; threshold: number; slaHours: number }[]>(),
  defaultDigestTime: varchar("default_digest_time", { length: 5 }).default("09:00"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Users table with organization support
export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  email: text("email").notNull().unique(),
  password: text("password").notNull(),
  fullName: text("full_name").notNull(),
  jobTitle: text("job_title"),
  phoneNumber: text("phone_number"),
  role: varchar("role", { length: 20 }).notNull(), // Admin, Approver, Finance, Member
  department: text("department"),
  digestTime: varchar("digest_time", { length: 5 }).default("09:00"),
  notificationPreferences: jsonb("notification_preferences").default({ push: true, email: true }).$type<{ push: boolean; email: boolean }>(),
  isOnline: boolean("is_online").default(false),
  customFieldsData: jsonb("custom_fields_data").default({}).$type<Record<string, string>>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Approval chains configuration - defines multi-level approval workflows
export const approvalChains = pgTable("approval_chains", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(), // e.g., "Finance Team Approval", "Department Head Chain"
  department: text("department"), // Optional: department-specific chain
  category: varchar("category", { length: 50 }), // Optional: category-specific chain (Advance, Reimbursement, etc)
  isDefault: boolean("is_default").default(false), // Is this the default chain for the org
  levels: jsonb("levels").notNull().$type<{ level: number; approverId: string; approverName: string; canSkip: boolean }[]>(), // Array of approval levels
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Approval history - tracks each approval action with timestamps
export const approvalHistory = pgTable("approval_history", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requestId: varchar("request_id").notNull().references((): any => fundingRequests.id, { onDelete: "cascade" }),
  level: integer("level").notNull(), // Which approval level this action represents
  approverId: varchar("approver_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  action: varchar("action", { length: 20 }).notNull(), // Approved, Rejected, RequestInfo, Overridden
  comments: text("comments"),
  isFastTrack: boolean("is_fast_track").default(false), // Was this a fast-track/override approval
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Funding requests table (now called "Queries" in UI)
export const fundingRequests = pgTable("funding_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  requesterId: varchar("requester_id").notNull().references(() => users.id, { onDelete: "cascade" }),
  approverId: varchar("approver_id").references(() => users.id, { onDelete: "set null" }),
  title: text("title").notNull(),
  description: text("description").notNull(),
  amount: integer("amount").notNull(),
  category: varchar("category", { length: 50 }).notNull(), // Advance, Reimbursement, Vendor, Budget, Other
  customCategory: text("custom_category"), // Used when category is "Other"
  status: varchar("status", { length: 20 }).notNull().default("Open"), // Open, Needs Info, Approved, Rejected, Closed
  currentApprovalLevel: integer("current_approval_level").default(1), // Tracks which level is currently reviewing
  approvalChainId: varchar("approval_chain_id").references((): any => approvalChains.id, { onDelete: "set null" }), // Which approval chain to follow
  participants: jsonb("participants").default([]).$type<string[]>(), // Array of user IDs
  attachments: jsonb("attachments").default([]).$type<{ id: string; name: string; url: string; size: number }[]>(),
  checklist: jsonb("checklist").default([]).$type<{ id: string; item: string; type: string; required: boolean; completed: boolean; value?: string }[]>(),
  aiSummary: text("ai_summary"),
  slaDeadline: timestamp("sla_deadline"),
  lastActivityAt: timestamp("last_activity_at").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

// Messages/chat on queries (formerly comments)
export const queryMessages = pgTable("query_messages", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  requestId: varchar("request_id").notNull().references(() => fundingRequests.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }), // null for system messages
  messageType: varchar("message_type", { length: 20 }).notNull().default("text"), // text, file, system_event
  content: text("content").notNull(),
  attachments: jsonb("attachments").default([]).$type<{ id: string; name: string; url: string; size: number }[]>(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Hierarchy levels - customizable level definitions for org chart
export const hierarchyLevels = pgTable("hierarchy_levels", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  name: text("name").notNull(), // e.g., "Executive", "Director", "Manager"
  levelOrder: integer("level_order").notNull(), // 1 (top) to N (bottom)
  color: varchar("color", { length: 7 }).notNull().default("#0EA5E9"), // Hex color for this level
  description: text("description"), // Optional description
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Organization chart nodes
export const orgChartNodes = pgTable("org_chart_nodes", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  userId: varchar("user_id").references(() => users.id, { onDelete: "cascade" }),
  name: text("name").notNull(),
  role: text("role").notNull(),
  department: text("department"),
  parentId: varchar("parent_id").references((): any => orgChartNodes.id, { onDelete: "set null" }),
  hierarchyLevelId: varchar("hierarchy_level_id").references((): any => hierarchyLevels.id, { onDelete: "set null" }), // Link to hierarchy level
  position: jsonb("position").default({ x: 0, y: 0 }).$type<{ x: number; y: number }>(),
  color: varchar("color", { length: 7 }).default("#0EA5E9"),
  shape: varchar("shape", { length: 20 }).default("rectangle"), // rectangle, circle, rounded
});

// Invite tokens for secure user invitations
export const inviteTokens = pgTable("invite_tokens", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  orgId: varchar("org_id").notNull().references(() => organizations.id, { onDelete: "cascade" }),
  token: varchar("token", { length: 100 }).notNull().unique(),
  role: varchar("role", { length: 20 }).notNull(), // Admin, Approver, Requester
  createdBy: varchar("created_by").notNull().references(() => users.id, { onDelete: "cascade" }),
  expiresAt: timestamp("expires_at").notNull(),
  usedAt: timestamp("used_at"),
  usedBy: varchar("used_by").references(() => users.id, { onDelete: "set null" }),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Relations
export const organizationsRelations = relations(organizations, ({ many }) => ({
  users: many(users),
  fundingRequests: many(fundingRequests),
  orgChartNodes: many(orgChartNodes),
}));

export const usersRelations = relations(users, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [users.orgId],
    references: [organizations.id],
  }),
  requestedFunding: many(fundingRequests, { relationName: "requester" }),
  approvingFunding: many(fundingRequests, { relationName: "approver" }),
  messages: many(queryMessages),
  orgChartNode: one(orgChartNodes, {
    fields: [users.id],
    references: [orgChartNodes.userId],
  }),
}));

export const fundingRequestsRelations = relations(fundingRequests, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [fundingRequests.orgId],
    references: [organizations.id],
  }),
  requester: one(users, {
    fields: [fundingRequests.requesterId],
    references: [users.id],
    relationName: "requester",
  }),
  approver: one(users, {
    fields: [fundingRequests.approverId],
    references: [users.id],
    relationName: "approver",
  }),
  approvalChain: one(approvalChains, {
    fields: [fundingRequests.approvalChainId],
    references: [approvalChains.id],
  }),
  messages: many(queryMessages),
  approvalHistory: many(approvalHistory),
}));

export const approvalChainsRelations = relations(approvalChains, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [approvalChains.orgId],
    references: [organizations.id],
  }),
  requests: many(fundingRequests),
}));

export const approvalHistoryRelations = relations(approvalHistory, ({ one }) => ({
  request: one(fundingRequests, {
    fields: [approvalHistory.requestId],
    references: [fundingRequests.id],
  }),
  approver: one(users, {
    fields: [approvalHistory.approverId],
    references: [users.id],
  }),
}));

export const queryMessagesRelations = relations(queryMessages, ({ one }) => ({
  request: one(fundingRequests, {
    fields: [queryMessages.requestId],
    references: [fundingRequests.id],
  }),
  user: one(users, {
    fields: [queryMessages.userId],
    references: [users.id],
  }),
}));

export const hierarchyLevelsRelations = relations(hierarchyLevels, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [hierarchyLevels.orgId],
    references: [organizations.id],
  }),
  nodes: many(orgChartNodes),
}));

export const orgChartNodesRelations = relations(orgChartNodes, ({ one, many }) => ({
  organization: one(organizations, {
    fields: [orgChartNodes.orgId],
    references: [organizations.id],
  }),
  user: one(users, {
    fields: [orgChartNodes.userId],
    references: [users.id],
  }),
  hierarchyLevel: one(hierarchyLevels, {
    fields: [orgChartNodes.hierarchyLevelId],
    references: [hierarchyLevels.id],
  }),
  parent: one(orgChartNodes, {
    fields: [orgChartNodes.parentId],
    references: [orgChartNodes.id],
    relationName: "hierarchy",
  }),
  children: many(orgChartNodes, { relationName: "hierarchy" }),
}));

export const inviteTokensRelations = relations(inviteTokens, ({ one }) => ({
  organization: one(organizations, {
    fields: [inviteTokens.orgId],
    references: [organizations.id],
  }),
  creator: one(users, {
    fields: [inviteTokens.createdBy],
    references: [users.id],
    relationName: "creator",
  }),
  user: one(users, {
    fields: [inviteTokens.usedBy],
    references: [users.id],
    relationName: "user",
  }),
}));

// Insert and Select schemas
export const insertOrganizationSchema = createInsertSchema(organizations).omit({
  id: true,
  createdAt: true,
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
}).extend({
  orgCode: z.string().min(1, "Organization code is required"),
});

export const insertFundingRequestSchema = createInsertSchema(fundingRequests).omit({
  id: true,
  orgId: true,
  requesterId: true,
  createdAt: true,
  updatedAt: true,
  aiSummary: true,
  status: true,
});

export const insertQueryMessageSchema = createInsertSchema(queryMessages).omit({
  id: true,
  createdAt: true,
});

export const insertOrgChartNodeSchema = createInsertSchema(orgChartNodes).omit({
  id: true,
  orgId: true,
});

export const insertInviteTokenSchema = createInsertSchema(inviteTokens).omit({
  id: true,
  createdAt: true,
  usedAt: true,
  usedBy: true,
});

export const insertApprovalChainSchema = createInsertSchema(approvalChains).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertApprovalHistorySchema = createInsertSchema(approvalHistory).omit({
  id: true,
  createdAt: true,
});

export const insertHierarchyLevelSchema = createInsertSchema(hierarchyLevels).omit({
  id: true,
  orgId: true,
  createdAt: true,
});

// Types
export type Organization = typeof organizations.$inferSelect;
export type InsertOrganization = z.infer<typeof insertOrganizationSchema>;

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type FundingRequest = typeof fundingRequests.$inferSelect;
export type InsertFundingRequest = z.infer<typeof insertFundingRequestSchema>;

export type QueryMessage = typeof queryMessages.$inferSelect;
export type InsertQueryMessage = z.infer<typeof insertQueryMessageSchema>;

export type OrgChartNode = typeof orgChartNodes.$inferSelect;
export type InsertOrgChartNode = z.infer<typeof insertOrgChartNodeSchema>;

export type InviteToken = typeof inviteTokens.$inferSelect;
export type InsertInviteToken = z.infer<typeof insertInviteTokenSchema>;

export type ApprovalChain = typeof approvalChains.$inferSelect;
export type InsertApprovalChain = z.infer<typeof insertApprovalChainSchema>;

export type ApprovalHistory = typeof approvalHistory.$inferSelect;
export type InsertApprovalHistory = z.infer<typeof insertApprovalHistorySchema>;

export type HierarchyLevel = typeof hierarchyLevels.$inferSelect;
export type InsertHierarchyLevel = z.infer<typeof insertHierarchyLevelSchema>;
